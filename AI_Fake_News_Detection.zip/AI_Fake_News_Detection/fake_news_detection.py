
import re
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.neighbors import KNeighborsClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.neural_network import MLPClassifier
from sklearn.metrics import accuracy_score, classification_report, ConfusionMatrixDisplay

# Download Kaggle fake news dataset and place train.csv beside this file.
data = pd.read_csv("train.csv")

text_col = "text" if "text" in data.columns else data.columns[-2]
label_col = "label" if "label" in data.columns else data.columns[-1]

data = data[[text_col,label_col]].dropna()

def clean_text(text):
    text = re.sub(r'\\W',' ',str(text))
    return text.lower()

X = data[text_col].apply(clean_text)
y = data[label_col]

vec = TfidfVectorizer(max_features=5000, stop_words="english")
Xv = vec.fit_transform(X)
X_train,X_test,y_train,y_test = train_test_split(Xv,y,test_size=0.2,random_state=42)

models={
"KNN":KNeighborsClassifier(5),
"Logistic Regression":LogisticRegression(max_iter=1000),
"Random Forest":RandomForestClassifier(n_estimators=100,random_state=42),
"Neural Network":MLPClassifier(hidden_layer_sizes=(100,),max_iter=300,random_state=42)
}
scores={}
best=None
best_name=""
for name,m in models.items():
    m.fit(X_train,y_train)
    pred=m.predict(X_test)
    acc=accuracy_score(y_test,pred)
    scores[name]=acc
    print(f"\n{name}: {acc:.4f}")
    print(classification_report(y_test,pred))
    if acc> (scores.get(best_name,0) if best_name else 0):
        best=m;best_name=name;best_pred=pred

plt.figure(figsize=(6,4))
plt.bar(scores.keys(),scores.values())
plt.xticks(rotation=20)
plt.ylabel("Accuracy")
plt.tight_layout()
plt.savefig("accuracy_comparison.png")

disp=ConfusionMatrixDisplay.from_predictions(y_test,best_pred)
plt.tight_layout()
plt.savefig("confusion_matrix.png")
print("Best model:",best_name)
