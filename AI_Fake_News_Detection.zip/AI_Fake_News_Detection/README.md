
# AI Powered Fake News Detection

## Steps
1. Download the Kaggle Fake News dataset.
2. Place `train.csv` in the same folder.
3. Install requirements:
   pip install -r requirements.txt
4. Run:
   python fake_news_detection.py

Outputs:
- accuracy_comparison.png
- confusion_matrix.png
